export default function Footer(){
    return(
        <footer className="site-footer">
            <p>&copy; 2026 MetalEvents. All rights reserved.</p>
        </footer>
    )
}