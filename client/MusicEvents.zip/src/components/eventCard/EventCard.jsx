export default function EventCard (){
    return (
        <div className="event-card">
                <img
                    src="https://images.unsplash.com/photo-1511379938547-c1f69419868d"
                    alt="Dark Throne Festival"
                />
                <h4>Dark Throne Festival</h4>
                <p>12 July 2026 · Sofia</p>
                </div>
    )
}