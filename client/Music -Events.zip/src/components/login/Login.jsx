import { useState } from "react";

export default function Login() {
    
    const [formData, setFormData] = useState({
        email: "",
        password: "",
    });

     const onChangeHandler =  (e) => {
        setFormData(state => ({ ...state, [e.target.name]: e.target.value }));
        console.log(formData.email);
        console.log(formData.password);
    };

    console.log(formData);
    
  return (
    <div className="auth-page">
      <form className="auth-form">
        <h2>Login</h2>

        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            placeholder="metalhead@example.com"
            name="email"
            value={formData.email}
            onChange={onChangeHandler}
          />
        </div>

        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            placeholder="••••••••"
            name="password"
            value={formData.password}
            onChange={onChangeHandler}
          />
        </div>

        <button className="auth-btn">Login</button>

        <p className="auth-switch">
          Don’t have an account? <span>Register</span>
        </p>
      </form>
    </div>
  );
}
